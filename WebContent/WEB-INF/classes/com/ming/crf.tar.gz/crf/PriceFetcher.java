package com.ming.crf;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PriceFetcher {
	public static Price fetchPrice(String sen){
		Price price = new Price();
		ArrayList<String> reStrings = price.getValues();
		ArrayList<String> tmpStrings = null;
		if(sen==null)
			return price;
		sen = StringPreHandler.delKeyword(sen, "\\s+");
//		sen = StringPreHandler.numberTranslator(sen);
//		System.out.println(sen);
		String[] senStrings = sen.split("。|，|？");
		for(String s:senStrings){
			tmpStrings = fetchScalePrice(s);
			if(tmpStrings.size()==0)
				tmpStrings.addAll(fetchPointPrice(s));
			reStrings.addAll(tmpStrings);
			tmpStrings.clear();
		}
//		for(String s:reStrings){
//			System.out.println(s);
//		}
		return price;
	}

	
	private static ArrayList<String> fetchPointPrice(String s) {
		ArrayList<String> reStrings = new ArrayList<>();
		if(s==null)
			return reStrings;

		Matcher matcher = null;

		Pattern pointPattern = Pattern.compile("(价|费|(预算)).*?(\\d+)|(\\d+)(左右|上下)|(\\d+)元");

		
		matcher = pointPattern.matcher(s);
		if(!matcher.find())
			return reStrings;
		if(matcher.group(3)!=null)
			reStrings.add(matcher.group(3));
		if(matcher.group(4)!=null)
			reStrings.add(matcher.group(4));
		if(matcher.group(6)!=null)
			reStrings.add(matcher.group(6));
		
		return reStrings;
	}
	
	
	private static ArrayList<String> fetchScalePrice(String s) {
		ArrayList<String> reStrings = new ArrayList<>();
		if(s==null)
			return reStrings;
		
		Pattern pointPattern = Pattern.compile("(\\d+)\\D+(\\d+)");
		Matcher matcher = null;
		boolean isAboutPrice = false;
		if(s.contains("价") || s.contains("预算") 
				|| s.contains("费")||s.contains("元"))
			isAboutPrice = true;
		if(isAboutPrice){
			matcher = pointPattern.matcher(s);
			if(matcher.find()){
				reStrings.add(matcher.group(1) + "-" + matcher.group(2));
			}
		}

		return reStrings;
	}
	public static void main(String[] args) throws IOException {
		
		String tmpString="我想咨询一下，深圳福田区能容纳450人开会的场地,费用在5000";
		Price price = fetchPrice(tmpString);
		ArrayList<String> senArrayList  = price.getValues();
		for(String s:senArrayList){
			System.out.println(s+" aaa");
		}
		
		
	}
}
