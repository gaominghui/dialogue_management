package com.ming.crf;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




public class PerNumFetcher {
	/**
	 * 
	 * @param sen 待处理的句子
	 * @return    PerNum实体，PerNum.values中包含句子中所含有的可能表达人数的数字
	 */
	public static PerNum fetchPerNum(String sen) {
		PerNum pr = new PerNum();
		ArrayList<String> reStrings = pr.getValues();
		if(sen==null)
			return null;
		sen = StringPreHandler.delKeyword(sen, "\\s+");
		sen = StringPreHandler.numberTranslator(sen);
		String[] senStrings = sen.split("。|，|？");
//		指示范围的正则表达式
		String pScale = "(\\d+)[人个]?((--)|(——)|到|(-)|至|~)(\\d+)?[人个]";
//		指示点的正则表达式
		String pPoint = "(\\d+(?=((几个)|个|多)?人))|(\\d+(?=(余|多)?名))";
		Pattern p = Pattern.compile(pScale);
		ArrayList<String> tmpReStrings = new ArrayList<>();
		for(String s:senStrings){
			Matcher m = p.matcher(s);
			while(m.find())
			tmpReStrings.add(m.group(2)+'-'+m.group(7));
			if(tmpReStrings.size()!=0){
				reStrings.addAll(tmpReStrings);
				tmpReStrings.clear();
			}
		}
		//if(reStrings.size()!=0)
		//	return null;
		p = Pattern.compile(pPoint);
		Matcher m = p.matcher(sen);
		while (m.find()) {
			reStrings.add(m.group(0));
		}
		pr.setValues(reStrings);
		return pr;
	}
	public static void main(String []args) throws IOException {
		PerNumFetcher ptFetcher = new PerNumFetcher();
		File file = new File("PerNum");
		BufferedReader bReader = new BufferedReader(new FileReader(file));
		String tmpString;
		while( (tmpString = bReader.readLine())!=null){
			System.out.println(tmpString);
			PerNum per = ptFetcher.fetchPerNum(tmpString);
			if(per!=null&&per.getValues()!=null){
				for(String s:per.getValues())
					System.out.println(s);
			}
			
		}
//		String string = "我是中国人。你是吗";
//		String[] reStrings = string.split("。");
//		for(String s:reStrings){
//			System.out.println(s);
//		}
		
	}
}
