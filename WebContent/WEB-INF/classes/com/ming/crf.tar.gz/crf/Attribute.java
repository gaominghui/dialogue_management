package com.ming.crf;

import java.util.ArrayList;
import java.util.List;

public class Attribute {
	private List<String> values;
	public Attribute(){
		//values=new List<String>();
	}

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

}
