package com.ming.crf;

import java.util.ArrayList;

public class TimePeriod extends Attribute{
	ArrayList<String> values;
	public TimePeriod() {
		// TODO Auto-generated constructor stub
		values = new ArrayList<>();
	}
	public ArrayList<String> getValues() {
		return values;
	}
	public void setValues(ArrayList<String> values) {
		this.values = values;
	}
	
	
}
