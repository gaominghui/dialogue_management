package com.ming.crf;
import java.io.IOException;

import com.ming.time.TimeFetcher;

public class Fetch {
	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public PerNum getPernum() {
		return pernum;
	}

	public void setPernum(PerNum pernum) {
		this.pernum = pernum;
	}

	public Price getPrice() {
		return price;
	}

	public void setPrice(Price price) {
		this.price = price;
	}

	public Time getTime() {
		return time;
	}

	public void setTime(Time time) {
		this.time = time;
	}

	public TimePeriod getTimePeriod() {
		return timeperiod;
	}

	public void setTimePeriod(TimePeriod timeperiod) {
		this.timeperiod = timeperiod;
	}
	TimePeriod timeperiod;
	Location location;
	PerNum pernum;
	Price price;
	Time time;
	//HowLong howlong;
	LocationFetcher locationfetcher=new LocationFetcher();
	TimeFetcher timefetcher = new TimeFetcher("", "");
	public  Attribute find(int i){
		switch(i){
		case 0:
			Location location=this.getLocation();
			return location;
		case 1:
			PerNum pernum=this.getPernum();
			return pernum;
		case 2:
			Time time=this.getTime();
			return time;
		case 3:
			TimePeriod timeperiod=this.getTimePeriod();
			return timeperiod;
		case 4:
			Price price=this.getPrice();
			return price;
		default:
			return null;
		}
	}
	public  void fetch(String sentence) throws IOException{
		
		//获取地址

	
		//获取人数
		PerNum pernum=PerNumFetcher.fetchPerNum(sentence);
		
		//获取日期
		Time time=timefetcher.fetchTime(sentence);
	
		//获取多长时间
		TimePeriod timeperiod=TimePeriodFetcher.fetchTimePeriod(sentence);
		
		//获取报价
		Price price=PriceFetcher.fetchPrice(sentence);
		
		Location location=locationfetcher.fetchLoc(sentence);
		this.setLocation(location);
		this.setPernum(pernum);
		this.setTime(time);
		this.setTimePeriod(timeperiod);
		this.setPrice(price);
		
	
	}
	
	public  void print() throws IOException {
		// TODO Auto-generated method stub
	
		
		
		///print location
		for(int i=0;i<5;i++){
			
			if(this.find(i)!=null){
				if(this.find(i).getValues()!=null){
					System.out.print("attribue： ");
					for(String str:this.find(i).getValues()){
						System.out.println(str);
					}
					
				}
				else
					System.out.println("attribue.values is null");
			}
			else
				System.out.println("attribue is null");
			
		}
		

		

	}

}
